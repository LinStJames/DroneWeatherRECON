// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Hodekontroller",signin:"Logg p\u00e5",signout:"Logg ut",about:"Om",signInTo:"Logg inn p\u00e5",cantSignOutTip:"Denne funksjonen er ikke relevant i forh\u00e5ndsvisningsmodus.",more:"mer",_localized:{}}});