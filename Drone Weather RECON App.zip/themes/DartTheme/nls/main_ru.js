// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/nls/strings":{_themeLabel:"\u0422\u0435\u043c\u0430 \u0434\u0440\u043e\u0442\u0438\u043a\u0430",_layout_default:"\u041a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0430 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e",_localized:{}}});