// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BillboardTheme/nls/strings":{_themeLabel:"\u5e03\u544a\u680f\u4e3b\u9898",_layout_default:"\u9ed8\u8ba4\u5e03\u5c40",_layout_right:"\u53f3\u4fa7\u5e03\u5c40",_localized:{}}});