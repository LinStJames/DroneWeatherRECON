// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BillboardTheme/nls/strings":{_themeLabel:"\u0645\u0648\u0636\u0648\u0639 \u0644\u0648\u062d\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",_layout_default:"\u062a\u062e\u0637\u064a\u0637 \u0627\u0641\u062a\u0631\u0627\u0636\u064a",_layout_right:"\u0645\u062e\u0637\u0637 \u0625\u0644\u0649 \u0627\u0644\u064a\u0645\u064a\u0646",_localized:{}}});