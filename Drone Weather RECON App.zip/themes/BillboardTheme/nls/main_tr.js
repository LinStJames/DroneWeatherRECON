// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BillboardTheme/nls/strings":{_themeLabel:"\u0130lan Panosu Temas\u0131",_layout_default:"Varsay\u0131lan D\u00fczen",_layout_right:"Do\u011fru D\u00fczen",_localized:{}}});