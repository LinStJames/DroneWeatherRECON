// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Papuo\u0161al\u0173 d\u0117\u017eut\u0117s tema",_layout_default:"Numatytasis maketas",_layout_layout1:"1 maketas",emptyDocablePanelTip:"Paspauskite mygtuk\u0105 + valdiklio skirtuke, kad \u012ftrauktum\u0117te valdikl\u012f. ",_localized:{}}});