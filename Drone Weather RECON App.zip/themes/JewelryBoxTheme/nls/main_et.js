// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Teema Jewelry Box",_layout_default:"Vaikimisi paigutus",_layout_layout1:"Paigutus 1",emptyDocablePanelTip:"Vidina lisamiseks kl\u00f5psake sakil Vidin nuppu +. ",_localized:{}}});