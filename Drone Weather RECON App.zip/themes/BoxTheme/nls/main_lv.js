// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BoxTheme/nls/strings":{_themeLabel:"Lodzi\u0146a dizains",_layout_default:"Noklus\u0113juma izk\u0101rtojums",_layout_top:"Aug\u0161da\u013cas izk\u0101rtojums",_localized:{}}});